﻿using System;
using System.Collections.Generic;

namespace Mentor.Models
{
    public partial class Payment
    {
        public long Id { get; set; }
        public int UserId { get; set; }
        public string PaymentMethod { get; set; }
        public double? AmountPaid { get; set; }
        public string TransactionStatus { get; set; }
    }
}
